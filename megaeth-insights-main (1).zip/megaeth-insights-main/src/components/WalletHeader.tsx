import { Search, Zap } from "lucide-react";
import { useState } from "react";

interface WalletHeaderProps {
  onSearch: (address: string) => void;
}

const WalletHeader = ({ onSearch }: WalletHeaderProps) => {
  const [address, setAddress] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (address.trim()) onSearch(address.trim());
  };

  return (
    <header className="mb-10">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center glow-cyan">
          <Zap className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold font-display text-gradient-cyan">
            MEGAETH DASHBOARD
          </h1>
          <p className="text-xs font-mono text-muted-foreground">
            Testnet Activity Tracker & Airdrop Checker
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 relative max-w-2xl">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Enter wallet address (0x...)"
          className="w-full pl-11 pr-28 py-3 rounded-lg bg-secondary border border-border/50 text-foreground font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:glow-cyan transition-all"
        />
        <button
          type="submit"
          className="absolute right-2 top-1/2 -translate-y-1/2 px-5 py-1.5 rounded-md bg-primary text-primary-foreground font-mono text-sm font-semibold hover:glow-cyan-strong transition-all"
        >
          SCAN
        </button>
      </form>
    </header>
  );
};

export default WalletHeader;
