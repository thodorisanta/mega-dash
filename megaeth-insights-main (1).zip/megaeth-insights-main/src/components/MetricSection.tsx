import { LucideIcon } from "lucide-react";

interface MetricSectionProps {
  title: string;
  icon: LucideIcon;
  children: React.ReactNode;
}

const MetricSection = ({ title, icon: Icon, children }: MetricSectionProps) => {
  return (
    <section className="mb-10">
      <div className="flex items-center gap-3 mb-5">
        <div className="w-8 h-8 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <h2 className="section-title">{title}</h2>
        <div className="flex-1 h-px bg-border/50" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {children}
      </div>
    </section>
  );
};

export default MetricSection;
