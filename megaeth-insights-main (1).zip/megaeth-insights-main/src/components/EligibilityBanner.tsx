import { Shield, TrendingUp } from "lucide-react";

interface EligibilityBannerProps {
  score: number;
  rank: string;
}

const EligibilityBanner = ({ score, rank }: EligibilityBannerProps) => {
  const getScoreColor = () => {
    if (score >= 80) return "text-success";
    if (score >= 50) return "text-warning";
    return "text-destructive";
  };

  const getScoreLabel = () => {
    if (score >= 80) return "HIGH";
    if (score >= 50) return "MEDIUM";
    return "LOW";
  };

  return (
    <div className="glass-card p-6 mb-10 border-primary/20 glow-cyan">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Shield className="w-7 h-7 text-primary" />
          </div>
          <div>
            <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
              Estimated Airdrop Eligibility
            </p>
            <div className="flex items-center gap-3">
              <span className={`font-mono text-4xl font-bold ${getScoreColor()}`}>
                {score}
              </span>
              <span className="text-xs font-mono text-muted-foreground">/100</span>
              <span className={`text-xs font-mono font-semibold px-2 py-0.5 rounded-full border ${
                score >= 80 ? 'bg-success/10 border-success/30 text-success' :
                score >= 50 ? 'bg-warning/10 border-warning/30 text-warning' :
                'bg-destructive/10 border-destructive/30 text-destructive'
              }`}>
                {getScoreLabel()}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <TrendingUp className="w-4 h-4" />
          <span className="font-mono text-sm">Rank: {rank}</span>
        </div>
      </div>
    </div>
  );
};

export default EligibilityBanner;
