import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  subtitle?: string;
  highlight?: boolean;
}

const MetricCard = ({ label, value, icon: Icon, subtitle, highlight }: MetricCardProps) => {
  return (
    <div className={`glass-card p-4 transition-all duration-300 hover:border-glow hover:glow-cyan group ${highlight ? 'border-primary/30 glow-cyan' : ''}`}>
      <div className="flex items-start justify-between mb-3">
        <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <Icon className="w-4 h-4 text-primary/50 group-hover:text-primary transition-colors" />
      </div>
      <div className="font-mono text-2xl font-bold text-foreground tracking-tight">
        {value}
      </div>
      {subtitle && (
        <p className="text-xs text-muted-foreground mt-1 font-mono">{subtitle}</p>
      )}
    </div>
  );
};

export default MetricCard;
