import { useState } from "react";
import {
  Activity, FileCode, Flame, Coins, Box, Layers,
  Image, Palette, ShoppingBag, TrendingUp,
  ArrowLeftRight, RefreshCw,
  Wallet, Clock, Calendar, CalendarDays, Star, Hash, Fuel, ArrowUpRight, DollarSign,
  Crown, Loader2
} from "lucide-react";
import WalletHeader from "@/components/WalletHeader";
import MetricSection from "@/components/MetricSection";
import MetricCard from "@/components/MetricCard";
import EligibilityBanner from "@/components/EligibilityBanner";
import { fetchWalletData, fetchEthPrice, formatEth, WalletData } from "@/lib/megaeth-api";

function computeEligibilityScore(data: WalletData): number {
  let score = 0;
  score += Math.min(20, Math.floor(data.totalTx / 25));
  score += Math.min(15, Math.floor(data.daysActive / 5));
  score += Math.min(15, Math.floor(data.uniqueContracts / 5));
  score += Math.min(10, data.uniqueTokens);
  score += Math.min(10, data.nftTransfers);
  score += Math.min(10, data.contractsCreated * 5);
  score += Math.min(10, Math.floor(data.swapCount / 3));
  const ageDays = parseInt(data.walletAge) || 0;
  score += Math.min(10, Math.floor(ageDays / 15));
  return Math.min(100, score);
}

function computeGasRank(gasUsage: string): string {
  const gas = parseInt(gasUsage) || 0;
  if (gas > 1_000_000_000) return "Top 1%";
  if (gas > 500_000_000) return "Top 5%";
  if (gas > 100_000_000) return "Top 10%";
  if (gas > 50_000_000) return "Top 25%";
  if (gas > 10_000_000) return "Top 50%";
  return "Below 50%";
}

const Index = () => {
  const [walletData, setWalletData] = useState<WalletData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ethPrice, setEthPrice] = useState(0);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const handleSearch = async (address: string) => {
    if (!/^0x[a-fA-F0-9]{40}$/.test(address)) {
      setError("Invalid wallet address. Please enter a valid 0x address.");
      return;
    }
    setLoading(true);
    setError(null);
    setWalletData(null);
    try {
      const [data, price] = await Promise.all([
        fetchWalletData(address),
        fetchEthPrice(),
      ]);
      setWalletData(data);
      setEthPrice(price);
      setLastUpdated(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch wallet data");
    } finally {
      setLoading(false);
    }
  };

  const d = walletData;
  const eligibilityScore = d ? computeEligibilityScore(d) : 0;
  const avgTxPerDay = d && d.daysActive > 0 ? (d.totalTx / d.daysActive).toFixed(1) : "0";

  const feesInUsd = d && ethPrice > 0
    ? `$${(Number(d.totalFeesWei) / 1e18 * ethPrice).toFixed(2)}`
    : null;

  const balanceInUsd = d && ethPrice > 0
    ? `$${(Number(d.balanceWei) / 1e18 * ethPrice).toFixed(2)}`
    : null;

  return (
    <div className="min-h-screen bg-background">
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(hsl(var(--primary) / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary) / 0.3) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <WalletHeader onSearch={handleSearch} />

        {lastUpdated && (
          <div className="mb-6 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="font-mono text-xs text-muted-foreground">
              Last updated: {lastUpdated.toLocaleDateString()} {lastUpdated.toLocaleTimeString()}
            </span>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="font-mono text-sm text-muted-foreground">
              Fetching on-chain data...
            </p>
          </div>
        )}

        {error && (
          <div className="glass-card p-6 mb-10 border-destructive/30">
            <p className="font-mono text-sm text-destructive">{error}</p>
          </div>
        )}

        {!d && !loading && !error && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <Wallet className="w-12 h-12 text-muted-foreground/30" />
            <p className="font-mono text-sm text-muted-foreground">
              Enter a wallet address to view MegaETH activity
            </p>
          </div>
        )}

        {d && (
          <>
            <EligibilityBanner
              score={eligibilityScore}
              rank={computeGasRank(d.gasUsage)}
            />

            <MetricSection title="Activity Metrics" icon={Activity}>
              <MetricCard label="Unique Contracts" value={d.uniqueContracts.toLocaleString()} icon={FileCode} />
              <MetricCard label="Avg TX / Day" value={avgTxPerDay} icon={TrendingUp} />
              <MetricCard label="Gas Usage Rank" value={computeGasRank(d.gasUsage)} icon={Flame} highlight />
              <MetricCard label="Total Transactions" value={d.totalTx.toLocaleString()} icon={Hash} />
              <MetricCard label="Contracts Created" value={d.contractsCreated} icon={Box} />
              <MetricCard label="Tokens Transacted" value={d.uniqueTokens} icon={Coins} />
            </MetricSection>

            <MetricSection title="NFT Metrics" icon={Image}>
              <MetricCard label="Total NFT TX" value={d.nftTransfers.toLocaleString()} icon={Layers} />
              <MetricCard label="NFTs Minted" value={d.nftsMinted} icon={Palette} />
              <MetricCard label="Collections" value={d.nftCollections} icon={ShoppingBag} />
            </MetricSection>

            <MetricSection title="DeFi Activity" icon={ArrowLeftRight}>
              <MetricCard label="Transaction Count" value={d.totalTx.toLocaleString()} icon={Hash} />
              <MetricCard label="Total Swaps" value={d.swapCount.toLocaleString()} icon={RefreshCw} />
            </MetricSection>

            <MetricSection title="Wallet Profile" icon={Wallet}>
              <MetricCard label="Wallet Age" value={d.walletAge} icon={Clock} />
              <MetricCard
                label="Total Fees Spent"
                value={d.totalFees}
                subtitle={feesInUsd || undefined}
                icon={Fuel}
              />
              <MetricCard label="Days Active" value={d.daysActive} icon={Calendar} />
              <MetricCard label="Weeks Active" value={d.weeksActive} icon={CalendarDays} />
              <MetricCard label="Months Active" value={d.monthsActive} icon={CalendarDays} />
              <MetricCard
                label="Wallet Balance"
                value={d.balance}
                subtitle={balanceInUsd || undefined}
                icon={Wallet}
                highlight
              />
              <MetricCard label="First Transaction" value={d.firstTxDate || "N/A"} icon={ArrowUpRight} />
              <MetricCard label="Last Transaction" value={d.lastTxDate || "N/A"} icon={ArrowUpRight} />
              <MetricCard label="Gas Used" value={parseInt(d.gasUsage).toLocaleString()} icon={Flame} />
            </MetricSection>

            <MetricSection title="MegaMafia Projects" icon={Crown}>
              <MetricCard label="Eligibility Score" value={`${eligibilityScore}/100`} icon={Star} highlight />
            </MetricSection>
          </>
        )}

        <footer className="mt-16 pb-8 text-center">
          <p className="font-mono text-xs text-muted-foreground">
            MEGAETH DASHBOARD — Powered by Blockscout Explorer API
          </p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
