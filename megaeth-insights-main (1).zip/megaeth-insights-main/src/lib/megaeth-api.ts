const BLOCKSCOUT_API = "https://megaeth.blockscout.com/api/v2";

export interface AddressInfo {
  hash: string;
  coin_balance: string;
  block_number_balance_updated_at: number;
  is_contract: boolean;
  has_token_transfers: boolean;
  has_tokens: boolean;
  creation_transaction_hash: string | null;
}

export interface AddressCounters {
  transactions_count: string;
  token_transfers_count: string;
  gas_usage_count: string;
  validations_count: string;
}

export interface Transaction {
  hash: string;
  block: number;
  timestamp: string;
  from: { hash: string };
  to: { hash: string; name?: string | null; metadata?: { tags?: Array<{ name: string }> } } | null;
  value: string;
  gas_used: string;
  gas_price: string;
  fee: { value: string };
  method: string | null;
  tx_types: string[];
  transaction_types: string[];
  status: string;
  decoded_input?: { method_call?: string } | null;
}

export interface TokenTransfer {
  token: {
    address_hash: string;
    name: string;
    symbol: string;
    type: string;
  };
  total: { value: string; decimals: string };
  type: string;
  timestamp: string;
  method: string | null;
}

export interface WalletData {
  address: string;
  balance: string;
  balanceWei: string;
  totalTx: number;
  tokenTransfersCount: number;
  gasUsage: string;
  transactions: Transaction[];
  tokenTransfers: TokenTransfer[];
  uniqueContracts: number;
  contractsCreated: number;
  totalFees: string;
  totalFeesWei: string;
  firstTxDate: string | null;
  lastTxDate: string | null;
  daysActive: number;
  weeksActive: number;
  monthsActive: number;
  walletAge: string;
  uniqueTokens: number;
  nftTransfers: number;
  nftsMinted: number;
  nftCollections: number;
  swapCount: number;
}

async function fetchJson<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

async function fetchAllTransactions(address: string): Promise<Transaction[]> {
  const allTx: Transaction[] = [];
  let url: string | null = `${BLOCKSCOUT_API}/addresses/${address}/transactions`;
  
  let pages = 0;
  while (url && pages < 25) {
    const res = await fetch(url);
    if (!res.ok) break;
    const data = await res.json();
    allTx.push(...(data.items || []));
    if (data.next_page_params) {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(data.next_page_params)) {
        params.set(k, String(v));
      }
      url = `${BLOCKSCOUT_API}/addresses/${address}/transactions?${params.toString()}`;
    } else {
      url = null;
    }
    pages++;
  }
  return allTx;
}

async function fetchAllTokenTransfers(address: string): Promise<TokenTransfer[]> {
  const all: TokenTransfer[] = [];
  let url: string | null = `${BLOCKSCOUT_API}/addresses/${address}/token-transfers`;
  
  let pages = 0;
  while (url && pages < 25) {
    const res = await fetch(url);
    if (!res.ok) break;
    const data = await res.json();
    all.push(...(data.items || []));
    if (data.next_page_params) {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(data.next_page_params)) {
        params.set(k, String(v));
      }
      url = `${BLOCKSCOUT_API}/addresses/${address}/token-transfers?${params.toString()}`;
    } else {
      url = null;
    }
    pages++;
  }
  return all;
}

export function formatEth(wei: string): string {
  const eth = Number(wei) / 1e18;
  if (eth === 0) return "0 ETH";
  if (eth < 0.0001) return `${eth.toExponential(2)} ETH`;
  return `${eth.toFixed(4)} ETH`;
}

function daysBetween(d1: Date, d2: Date): number {
  return Math.floor(Math.abs(d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
}

// Known DeFi LP token types that use ERC-1155 but are NOT NFTs
const DEFI_LP_SYMBOLS = new Set(["LBT", "UNI-V3-POS"]);

function isRealNFT(tt: TokenTransfer): boolean {
  const tokenType = tt.token?.type;
  if (tokenType !== "ERC-721" && tokenType !== "ERC-1155") return false;
  // Filter out known DeFi LP tokens that use ERC-1155
  if (DEFI_LP_SYMBOLS.has(tt.token?.symbol)) return false;
  // Filter out liquidity-related methods
  const method = tt.method?.toLowerCase() || "";
  if (method.includes("liquidity") || method.includes("addliquidity") || method.includes("removeliquidity")) return false;
  return true;
}

function isSwapTransaction(tx: Transaction): boolean {
  const method = tx.method?.toLowerCase() || "";
  const toName = tx.to?.name?.toLowerCase() || "";
  const tags = tx.to?.metadata?.tags?.map(t => t.name.toLowerCase()) || [];
  
  // Check method name
  if (method.includes("swap")) return true;
  // Check if target is a known swap router
  if (toName.includes("swap") || toName.includes("router")) {
    if (method === "multicall" || method.includes("exact")) return true;
  }
  // Check tags
  if (tags.some(t => t.includes("swap") || t.includes("router"))) {
    if (tx.transaction_types?.includes("token_transfer")) return true;
  }
  // Check decoded input
  if (tx.decoded_input?.method_call?.toLowerCase().includes("swap")) return true;
  
  return false;
}

export async function fetchEthPrice(): Promise<number> {
  try {
    const res = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd");
    if (!res.ok) return 0;
    const data = await res.json();
    return data.ethereum?.usd || 0;
  } catch {
    return 0;
  }
}

export async function fetchWalletData(address: string): Promise<WalletData> {
  const [info, counters, transactions, tokenTransfers] = await Promise.all([
    fetchJson<AddressInfo>(`${BLOCKSCOUT_API}/addresses/${address}`),
    fetchJson<AddressCounters>(`${BLOCKSCOUT_API}/addresses/${address}/counters`),
    fetchAllTransactions(address),
    fetchAllTokenTransfers(address),
  ]);

  const balanceWei = info.coin_balance || "0";
  const balance = formatEth(balanceWei);
  const totalTx = parseInt(counters.transactions_count) || 0;
  const tokenTransfersCount = parseInt(counters.token_transfers_count) || 0;

  // Unique contracts
  const contractAddresses = new Set<string>();
  transactions.forEach((tx) => {
    if (tx.to?.hash && tx.to.hash.toLowerCase() !== address.toLowerCase()) {
      contractAddresses.add(tx.to.hash.toLowerCase());
    }
  });

  const contractsCreated = transactions.filter((tx) => !tx.to).length;

  // Total fees
  const totalFeesWei = transactions.reduce(
    (sum, tx) => sum + BigInt(tx.fee?.value || "0"),
    BigInt(0)
  );
  const totalFees = formatEth(totalFeesWei.toString());

  // Date analysis
  const txDates = transactions
    .map((tx) => new Date(tx.timestamp))
    .filter((d) => !isNaN(d.getTime()))
    .sort((a, b) => a.getTime() - b.getTime());

  const firstTxDate = txDates.length > 0 ? txDates[0].toISOString().split("T")[0] : null;
  const lastTxDate = txDates.length > 0 ? txDates[txDates.length - 1].toISOString().split("T")[0] : null;

  const activeDays = new Set<string>();
  const activeWeeks = new Set<string>();
  const activeMonths = new Set<string>();
  txDates.forEach((d) => {
    activeDays.add(d.toISOString().split("T")[0]);
    const weekStart = new Date(d);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    activeWeeks.add(weekStart.toISOString().split("T")[0]);
    activeMonths.add(`${d.getFullYear()}-${d.getMonth()}`);
  });

  const walletAgeDays = firstTxDate ? daysBetween(new Date(firstTxDate), new Date()) : 0;
  const walletAge = walletAgeDays > 0 ? `${walletAgeDays} days` : "N/A";

  // Unique tokens (fix: use address_hash)
  const uniqueTokens = new Set<string>();
  tokenTransfers.forEach((tt) => {
    if (tt.token?.address_hash) uniqueTokens.add(tt.token.address_hash.toLowerCase());
  });

  // NFT analysis (filter out DeFi LP tokens)
  const realNftTransfers = tokenTransfers.filter(isRealNFT);
  const nftsMinted = realNftTransfers.filter((tt) => tt.type === "token_minting").length;
  const nftCollections = new Set(
    realNftTransfers.map((tt) => tt.token?.address_hash?.toLowerCase()).filter(Boolean)
  ).size;

  // Swap detection (improved)
  const swapCount = transactions.filter(isSwapTransaction).length;

  return {
    address,
    balance,
    balanceWei,
    totalTx,
    tokenTransfersCount,
    gasUsage: counters.gas_usage_count,
    transactions,
    tokenTransfers,
    uniqueContracts: contractAddresses.size,
    contractsCreated,
    totalFees,
    totalFeesWei: totalFeesWei.toString(),
    firstTxDate,
    lastTxDate,
    daysActive: activeDays.size,
    weeksActive: activeWeeks.size,
    monthsActive: activeMonths.size,
    walletAge,
    uniqueTokens: uniqueTokens.size,
    nftTransfers: realNftTransfers.length,
    nftsMinted,
    nftCollections,
    swapCount,
  };
}
